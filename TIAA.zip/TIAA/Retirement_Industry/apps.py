from django.apps import AppConfig


class RetirementIndustryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Retirement_Industry'
 